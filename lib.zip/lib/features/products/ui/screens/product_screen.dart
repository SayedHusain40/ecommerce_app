import 'package:ecommerce_app/core/constants/app_assets.dart';
import 'package:ecommerce_app/core/di/dependency_injection.dart';
import 'package:ecommerce_app/core/helpers/extensions.dart';
import 'package:ecommerce_app/core/theme/constants/app_colors.dart';
import 'package:ecommerce_app/core/theme/constants/app_text_styles.dart';
import 'package:ecommerce_app/core/widgets/app_custom_app_bar.dart';
import 'package:ecommerce_app/features/products/logic/cubit/product_cubit.dart';
import 'package:ecommerce_app/features/products/ui/widgets/products_grid_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';

class ProductScreen extends StatefulWidget {
  final String? category;

  const ProductScreen({super.key, this.category});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  final TextEditingController searchController = TextEditingController();

  void onSearchClick() {
    searchController.clear();
    showModalBottomSheet(
      showDragHandle: true,
      isScrollControlled: true,
      useSafeArea: true,
      context: context,
      builder: (BuildContext sheetContext) {
        final brightness = Theme.of(sheetContext).brightness;
        return BlocProvider(
          create: (context) =>
              getIt<ProductCubit>()..getProductsBySearchQuery(searchQuery: ''),
          child: GestureDetector(
            onTap: () => FocusScope.of(sheetContext).unfocus(),
            behavior: HitTestBehavior.opaque,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: .spaceBetween,
                    children: [
                      SvgPicture.asset(AppImages.logo(brightness)),
                      GestureDetector(
                        onTap: () {
                          sheetContext.pop();
                        },
                        child: SvgPicture.asset(AppIcons.cancel(brightness)),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  TextFormField(
                    controller: searchController,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.only(
                        top: 16,
                        bottom: 16,
                        left: 0,
                        right: 16,
                      ),

                      prefixIcon: Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: SvgPicture.asset(AppIcons.searchGray),
                      ),
                      prefixIconConstraints: const BoxConstraints(
                        minWidth: 24,
                        minHeight: 24,
                      ),
                      hint: Text(
                        'Search..',
                        style: AppTextStyles.body3Regular.copyWith(
                          color: AppColors.grey150(brightness),
                        ),
                      ),
                    ),
                    onChanged: (value) {
                      sheetContext
                          .read<ProductCubit>()
                          .getProductsBySearchQuery(searchQuery: value);
                    },
                  ),
                  SizedBox(height: 20),
                  Expanded(child: ProductsGridView()),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final String appBarTitle = widget.category ?? 'Products';
    return Scaffold(
      appBar: AppCustomAppBar(
        title: appBarTitle,
        actions: [
          GestureDetector(
            onTap: onSearchClick,
            child: SvgPicture.asset(AppIcons.search(brightness)),
          ),
          SizedBox(width: 12),
          GestureDetector(
            onTap: () {},
            child: SvgPicture.asset(AppIcons.setting(brightness)),
          ),
          SizedBox(width: 16),
        ],
      ),
      body: Padding(
        padding: .symmetric(vertical: 12, horizontal: 16),
        child: ProductsGridView(category: widget.category),
      ),
    );
  }
}
