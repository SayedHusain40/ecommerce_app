import 'package:ecommerce_app/core/auth/app_auth_state.dart';
import 'package:ecommerce_app/core/di/dependency_injection.dart';
import 'package:ecommerce_app/core/routing/route_names.dart';
import 'package:ecommerce_app/features/categories/logic/cubit/category_cubit.dart';
import 'package:ecommerce_app/features/categories/ui/screens/category_screen.dart';
import 'package:ecommerce_app/features/forgot_password/logic/forgot_password_cubit.dart';
import 'package:ecommerce_app/features/forgot_password/ui/screens/confirmation_email_screen.dart';
import 'package:ecommerce_app/features/login/logic/login_cubit.dart';
import 'package:ecommerce_app/features/login/ui/login_screen.dart';
import 'package:ecommerce_app/features/onboarding/ui/screens/onboarding_screen.dart';
import 'package:ecommerce_app/features/products/data/model/product_model.dart';
import 'package:ecommerce_app/features/products/logic/cubit/product_cubit.dart';
import 'package:ecommerce_app/features/products/ui/screens/product_screen.dart';
import 'package:ecommerce_app/features/products/ui/widgets/product_detail_screen.dart';
import 'package:ecommerce_app/features/register/logic/register_cubit.dart';
import 'package:ecommerce_app/features/register/ui/screens/register_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AppRouter {
  const AppRouter();

  Route generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RouteNames.appAuthState:
        final sendEmailOnInit = (settings.arguments as bool?) ?? false;
        return MaterialPageRoute(
          builder: (context) => AppAuthState(sendEmailOnInit: sendEmailOnInit),
        );
      case RouteNames.onBoardingScreen:
        return MaterialPageRoute(builder: (context) => OnboardingScreen());
      // case RouteNames.homeScreen:
      //   return MaterialPageRoute(builder: (context) => HomeScreen());
      case RouteNames.loginScreen:
        return MaterialPageRoute(
          builder: (context) => BlocProvider(
            create: (context) => getIt<LoginCubit>(),
            child: LoginScreen(),
          ),
        );
      case RouteNames.registerScreen:
        return MaterialPageRoute(
          builder: (context) => BlocProvider(
            create: (context) => getIt<RegisterCubit>(),
            child: RegisterScreen(),
          ),
        );
      case RouteNames.confirmationEmailScreenScreen:
        return MaterialPageRoute(
          builder: (context) => BlocProvider(
            create: (context) => getIt<ForgotPasswordCubit>(),
            child: ConfirmationEmailScreen(),
          ),
        );
      case RouteNames.categoryScreen:
        return MaterialPageRoute(
          builder: (context) => BlocProvider.value(
            value: context
                .read<CategoryCubit>(), 
            child: CategoryScreen(),
          ),
        );

      case RouteNames.productScreen:
        final category = settings.arguments as String?;
        return MaterialPageRoute(
          builder: (context) => BlocProvider(
            create: (context) {
              if (category != null) {
                return getIt<ProductCubit>()
                  ..getProductsByCategory(category: category);
              }
              return getIt<ProductCubit>()..getProducts();
            },
            child: ProductScreen(category: category),
          ),
        );
      case RouteNames.productDetailScreen:
        final productModel = settings.arguments as ProductModel;
        return MaterialPageRoute(
          builder: (context) => ProductDetailScreen(productModel: productModel),
        );
      default:
        return MaterialPageRoute(builder: (context) => UndefinedRouteScreen());
    }
  }
}

class UndefinedRouteScreen extends StatelessWidget {
  const UndefinedRouteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Something went wrong', style: TextStyle(fontSize: 18)),

            const SizedBox(height: 16),

            // ElevatedButton(
            //   onPressed: () {
            //     Navigator.pushNamedAndRemoveUntil(
            //       context,
            //       RouteNames.homeScreen,
            //       (route) => false,
            //     );
            //   },
            //   child: const Text('Go Home'),
            // ),
          ],
        ),
      ),
    );
  }
}
